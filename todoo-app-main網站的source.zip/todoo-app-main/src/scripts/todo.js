import { initPages } from "./pages"
initPages()

// 程式碼寫在這裡
